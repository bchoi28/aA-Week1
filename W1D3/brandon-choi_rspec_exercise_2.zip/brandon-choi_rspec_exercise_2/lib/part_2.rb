def palindrome?(string)
    new_string = ""
    string.each_char {|char|new_string = char + new_string}
    new_string == string
end

p palindrome?("tot") # => true
p palindrome?("racecar") # => true
p palindrome?("madam") # => true
p palindrome?("aa") # => true
p palindrome?("a") # => true

def substrings(string)
    # array = []
    # (0...string.length).each do |idx1|
    #     (idx1...string.length).each do |idx2|
    #         array << string[idx1..idx2]
    #     end
    # end
    # array

    
end

p substrings("jump") # => ["j", "ju", "jum", "jump", "u", "um", "ump", "m", "mp", "p"]
p substrings("abc") # => ["a", "ab", "abc", "b", "bc", "c"]
p substrings("x") # => ["x"]

def palindrome_substrings(string)
    substrings(string).select {|sub| palindrome?(sub) && sub.length > 1 }
end

p palindrome_substrings("abracadabra") # => ["aca", "ada"]
p palindrome_substrings("madam") # => ["madam", "ada"]
p palindrome_substrings("taco") # => []

