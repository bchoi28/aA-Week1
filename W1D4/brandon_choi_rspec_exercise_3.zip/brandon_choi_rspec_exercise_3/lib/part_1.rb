def is_prime?(num)
    (2...num).each {|factor|return false if num % factor == 0}
    num > 1 
end

# def is_prime?(num)
#     (2...num).each {|factor|return false if num % factor == 0}
#     return false if num < 2
#     true
# end

def nth_prime(n)
    # if n = 300
    #     return #primenumber
    # we iterate through every number 
    # we stop when i = 300
    # we only increment n by 1 if this number is prime so we can move only

    i = 1
    current_num = 2
    while i < n
        current_num += 1
        if is_prime?(current_num)
            i += 1
        end
    end
    current_num
end

def prime_range(min, max)
    (min..max).select {|num|is_prime?(num)}
end